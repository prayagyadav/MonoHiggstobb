def Generate_Luminosity_file(good_json):
    
    pass